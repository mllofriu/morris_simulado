/*
 * File:         television.c
 * Date:         14 December 2010
 * Description:  Switch on the televisio prototype
 * Author:       fabien.rohrer@cyberbotics.com
 * Modifications:
 */

#include <stdlib.h> // exit and EXIT_SUCCESS
#include <stdio.h>

#include <webots/robot.h>
#include <webots/led.h>
#include <webots/display.h>

#define TIME_STEP 64

static void step() {
  if (wb_robot_step(TIME_STEP) == -1) {
    wb_robot_cleanup();
    exit(EXIT_SUCCESS);
  }
}

int main(int argc, char **argv)
{
  wb_robot_init();

  printf("Default controller of the television started...\n");

  // get the devices
  WbDeviceTag led = wb_robot_get_device("led");
  WbDeviceTag display = wb_robot_get_device("display");

  // switch on the led
  wb_led_set(led, 1);

  // load the image
  WbImageRef movie = wb_display_image_load(display, "movie.png");

  // main loop
  int counter = 0;
  while (true) {
    
    // display the next frame each step
    switch (counter%4) {
      case 0:
        wb_display_image_paste(display, movie, 0, 0);
        break;
      case 1:
        wb_display_image_paste(display, movie, -128, 0);
        break;
      case 2:
        wb_display_image_paste(display, movie, 0, -64);
        break;
      default:
        wb_display_image_paste(display, movie, -128, -64);
        break;
    }
    
    // update the counter
    counter++;
    
    // step
    step();
  }
  
  return EXIT_SUCCESS;
}
